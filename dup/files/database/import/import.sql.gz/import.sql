create table snow (
    test varchar(25)
);
